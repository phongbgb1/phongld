
let card = [
	{
		'card': 0,
		'type': 0
	},
	{
		'card': 0,
		'type': 1
	},
	{
		'card': 0,
		'type': 2
	},
	{
		'card': 0,
		'type': 3
	},
	{
		'card': 1,
		'type': 0
	},
	{
		'card': 1,
		'type': 1
	},
	{
		'card': 1,
		'type': 2
	},
	{
		'card': 1,
		'type': 3
	},
	{
		'card': 2,
		'type': 0
	},
	{
		'card': 2,
		'type': 1
	},
	{
		'card': 2,
		'type': 2
	},
	{
		'card': 2,
		'type': 3
	},
	{
		'card': 3,
		'type': 0
	},
	{
		'card': 3,
		'type': 1
	},
	{
		'card': 3,
		'type': 2
	},
	{
		'card': 3,
		'type': 3
	},
	{
		'card': 4,
		'type': 0
	},
	{
		'card': 4,
		'type': 1
	},
	{
		'card': 4,
		'type': 2
	},
	{
		'card': 4,
		'type': 3
	},
	{
		'card': 5,
		'type': 0
	},
	{
		'card': 5,
		'type': 1
	},
	{
		'card': 5,
		'type': 2
	},
	{
		'card': 5,
		'type': 3
	},
	{
		'card': 6,
		'type': 0
	},
	{
		'card': 6,
		'type': 1
	},
	{
		'card': 6,
		'type': 2
	},
	{
		'card': 6,
		'type': 3
	},
	{
		'card': 7,
		'type': 0
	},
	{
		'card': 7,
		'type': 1
	},
	{
		'card': 7,
		'type': 2
	},
	{
		'card': 7,
		'type': 3
	},
	{
		'card': 8,
		'type': 0
	},
	{
		'card': 8,
		'type': 1
	},
	{
		'card': 8,
		'type': 2
	},
	{
		'card': 8,
		'type': 3
	},
	{
		'card': 9,
		'type': 0
	},
	{
		'card': 9,
		'type': 1
	},
	{
		'card': 9,
		'type': 2
	},
	{
		'card': 9,
		'type': 3
	},
	{
		'card': 10,
		'type': 0
	},
	{
		'card': 10,
		'type': 1
	},
	{
		'card': 10,
		'type': 2
	},
	{
		'card': 10,
		'type': 3
	},
	{
		'card': 11,
		'type': 0
	},
	{
		'card': 11,
		'type': 1
	},
	{
		'card': 11,
		'type': 2
	},
	{
		'card': 11,
		'type': 3
	},
	{
		'card': 12,
		'type': 0
	},
	{
		'card': 12,
		'type': 1
	},
	{
		'card': 12,
		'type': 2
	},
	{
		'card': 12,
		'type': 3
	},
];
let name = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
let type = ['♥', '♦', '♣', '♠'];

module.exports = {
	card: card,
	name: name,
	type: type,
}
