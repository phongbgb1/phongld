
module.exports = {
	'extract':      0,                                         // Chiết khẩu 0%
	//'URL':          '', // URL APIhttps://naptudong.com/chargingws/v2
	'URL':          '', // URL API

	'APP_ID':       '000',                              // id app
    'APP_PASSWORD': '0000',        // pass app

    '99': 'Đang nạp...',
    '1': 'Nạp thẻ cào thành công.',
    '2': 'Thẻ cào sai mệnh giá.',
    '3': 'Thẻ nỗi.',
    '4': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',

/**
    '00': 'Nạp thẻ cào thành công.',
	'99': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'01': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'02': 'Dữ liệu gửi lên không hợp lệ.',
	'03': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'04': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'05': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'06': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'07': 'Thẻ cào đã qua sử dụng.',
	'08': 'Thẻ đã bị khóa.',
	'09': 'Thẻ hết đã hạn sử dụng.',
	'10': 'Thẻ không tồn tại.',
	'11': 'Mã thẻ sai định dạng.',
	'12': 'Sai số serial của thẻ.',
	'13': 'Mã thẻ và số serial không khớp.',
	'14': 'Thẻ không tồn tại.',
	'15': 'Thẻ không sử dụng được.',
	'16': 'Nhập sai quá giới hạn cho phép.',
	'17': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'18': 'Đang nạp...',
	'19': 'Không thể kết nối tới máy chủ.',
	'20': 'Đã gửi yêu cầu nạp thẻ.',
	'21': 'Hệ thống đang bảo trì, giữ lại thẻ và quay lại sau.',
	'22': 'Mệnh giá thẻ không hợp lệ.',
	*/
};
