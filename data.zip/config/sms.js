
module.exports = {
	'URL':       'https://api.wavecell.com/sms/v1/thickcuk9_2cCDE_hq/single',
	'Author':    '6PlFs3sAeHs3gdPcqR8PKG3prgbDb0xd5VFZ0r0',
	'Brandname': 'Bem68',
}
