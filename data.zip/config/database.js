
module.exports = {
	'url': 'mongodb://127.0.0.1:27017',
	'options': {
		//'user':   '00',
		//'pass':   '000',
		'dbName': 'admin',
		'useNewUrlParser': true,
		'useUnifiedTopology': true,
		//'autoIndex':       false,
	},
};
